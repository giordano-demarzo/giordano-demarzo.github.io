from bank_reserves.server import server

server.launch(open_browser=True)
