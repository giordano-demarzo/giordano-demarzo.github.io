from wolf_sheep.server import server

server.launch(open_browser=True)
