from virus_on_network.server import server

server.launch(open_browser=True)
