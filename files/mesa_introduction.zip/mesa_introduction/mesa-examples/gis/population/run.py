from population.server import server

server.launch()
