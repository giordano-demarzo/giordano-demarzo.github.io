from urban_growth.server import server

server.launch()
